s = input()
unique_chars = set(s)
print(''.join(unique_chars))